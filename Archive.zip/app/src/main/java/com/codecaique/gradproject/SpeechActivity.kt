package com.codecaique.gradproject

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*


class SpeechActivity : AppCompatActivity() {

    private val TAG = "SpeechActivity"
    private val REQ_CODE = 100
    var textView: TextView? = null
    var imageView: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_speech)

        var language = "ar-EG"
        language = "us-US";

        setContentView(R.layout.activity_speech)
        textView = findViewById<View>(R.id.text) as TextView?
        imageView = findViewById<View>(R.id.image) as ImageView?
        val speak: ImageView = findViewById(R.id.speak)
        speak.setOnClickListener{
            Log.e(TAG, "onCreate: speak.setOnClickListener")
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
//                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
//                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Need to speak")
            try {
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,language);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
                intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, language);
                startActivityForResult(intent, REQ_CODE)
            } catch (a: ActivityNotFoundException) {
                Toast.makeText(applicationContext,
                    "Sorry your device not supported",
                    Toast.LENGTH_SHORT).show()
            }



        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data);
        when (requestCode) {
            REQ_CODE -> {
                if (resultCode == RESULT_OK && null != data) {
                    var result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    var txt:String? = result?.get(0)

                    if(txt?.contains("hi") == true || txt?.contains("hello") == true){
                        textView?.setText(result?.get(0));
                        imageView?.setImageDrawable(resources.getDrawable(R.drawable.hi))
                    }
                    else{
                        textView?.setText("هذه الكلمه غير مترجمه يرجي اضافتها لقاعده البيانات");
                        imageView?.setImageDrawable(null)
                    }
                }
            }
        }
    }
}