package com.codecaique.gradproject

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class TextActivity : AppCompatActivity() {


    private val TAG = "SpeechActivity"
    private val REQ_CODE = 100
    var textView: TextView? = null
    var imageView: ImageView? = null
    var et_text: EditText? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        Log.e(TAG, "onCreate: ")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text)



        var language = "ar-EG"
        language = "us-US";

        textView = findViewById<View>(R.id.text) as TextView?
        imageView = findViewById<View>(R.id.image) as ImageView?
        et_text = findViewById<View>(R.id.et_text) as EditText?

    }

    fun trans(view: View) {
        if(et_text?.text?.contains("hi") == true || et_text?.text?.contains("hello") == true){

            imageView?.setImageDrawable(resources.getDrawable(R.drawable.hi))
        }
        else{
            textView?.setText("هذه الكلمه غير مترجمه يرجي اضافتها لقاعده البيانات");
            imageView?.setImageDrawable(null)
        }


        if(et_text?.text?.contains("اهلا") == true || et_text?.text?.contains("السلام عليكم") == true){
            textView?.setText("");
            imageView?.setImageDrawable(resources.getDrawable(R.drawable.hi))
        }
        else{
            textView?.setText("هذه الكلمه غير مترجمه يرجي اضافتها لقاعده البيانات");
            imageView?.setImageDrawable(null)
        }
    }
}