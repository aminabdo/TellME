package com.codecaique.gradproject

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View

class LanguageActivity : AppCompatActivity() {
    private val TAG = "LanguageActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language)
    }


    fun shared_en(){
//        val sharedPref = this?.getSharedPreferences(
//            "language", Context.MODE_PRIVATE)
//        with (sharedPref.edit()) {
//            putString("language", "english")
//            apply()
//        }

        val sharedPref = this?.getPreferences(Context.MODE_PRIVATE) ?: return
        with (sharedPref.edit()) {
            putString("language", "english")
            apply()
        }

    }

    fun shared_ar(){
//        val sharedPref = this?.getSharedPreferences(
//            "language", Context.MODE_PRIVATE)
//        with (sharedPref.edit()) {
//            putString("language", "english")
//            apply()
//        }

        val sharedPref = this?.getPreferences(Context.MODE_PRIVATE) ?: return
        with (sharedPref.edit()) {
            putString("language", "arabic")
            apply()
        }

    }

    fun arabic(view: View) {
        Log.e(TAG, "arabic: " )
        shared_ar()
        startTypeActivity()
    }
    fun english(view: View) {
        Log.e(TAG, "english: " )
        shared_en()
        startTypeActivity()
    }

    fun test(view: View) {
        val sharedPref = this?.getPreferences(Context.MODE_PRIVATE) ?: return
        val language = sharedPref.getString("language", "english")
        Log.e(TAG, "test: lang  ->  "+language)
    }

    fun startTypeActivity(){
        var i = Intent(this ,TypeActivity::class.java);
        startActivity(i)
    }
}